package msgcontext;

import java.util.ArrayList;

import util.WritetoFile;
import main.Competition;
import main.Game;
import main.Person;
import msgtool.MsgFactory;
import msgtool.MsgTool;

public class PotWinMsg implements MsgFactory {

	@Override
	public void getMsg(String msg) {
		// TODO Auto-generated method stub
		analysisMsg(msg);
	}

	private void analysisMsg(String msg) {
		// TODO Auto-generated method stub

		String[] msgSection = msg.split("\n");

		ArrayList<String[]> stringList = MsgTool.cutMsg(msgSection, 8);

		try {

			for (int i = 0; i < stringList.size(); i++) {
				Person person = Game.personHashMap.get(Integer
						.valueOf(stringList.get(i)[0]));
				person.setWinPot(Integer.valueOf(stringList.get(i)[1]));
			}

			Competition.getInstance().clearCompetitionMsg();

			// MsgTest test = new MsgTest();
			// test.personCompetitionTest();
		} catch (Exception e) {
			// TODO: handle exception
			WritetoFile.getInstance(Game.my_id).writeMsg(e.toString());
		}
	}

}
