package msgcontext;

import java.util.ArrayList;

import util.WritetoFile;
import main.Card;
import main.Game;
import msgtool.MsgFactory;
import msgtool.MsgTool;

public class HoldMsg implements MsgFactory {

	@Override
	public void getMsg(String msg) {
		// TODO Auto-generated method stub
		analysisMsg(msg);
	}

	private void analysisMsg(String msg) {
		// TODO Auto-generated method stub

		String[] msgSection = msg.split("\n");

		ArrayList<String[]> stringList = MsgTool.cutMsg(msgSection, 3);

		ArrayList<Card> cardList = new ArrayList<Card>();
		try {

			for (int i = 0; i < stringList.size(); i++) {
				Card card = new Card();
				card.setColor(stringList.get(i)[0]);
				card.setPoint(stringList.get(i)[1]);
				cardList.add(card);
			}

			Game.personHashMap.get(Game.my_id).setHold(cardList);

			// MsgTest test = new MsgTest();
			// test.holdMsgTest();
		} catch (Exception e) {
			// TODO: handle exception
			WritetoFile.getInstance(Game.my_id).writeMsg(e.toString());
		}
	}
}
