package msgcontext;

import java.util.ArrayList;

import util.WritetoFile;
import main.Competition;
import main.Game;
import msgtool.MsgFactory;
import msgtool.MsgTool;

public class BlindMsg implements MsgFactory {

	@Override
	public void getMsg(String msg) {
		// TODO Auto-generated method stub
		analysisMsg(msg);
	}

	private void analysisMsg(String msg) {
		// TODO Auto-generated method stub

		String[] msgSection = msg.split("\n");

		ArrayList<String[]> stringList = MsgTool.cutMsg(msgSection, 2);

		Competition competition = Competition.getInstance();

		 try {
		// 赋值person,Competition
		String[] bigBlind = stringList.get(0);
		competition.setBigBlind(Integer.valueOf(bigBlind[0]));
		Game.personHashMap.get(Integer.valueOf(bigBlind[0]))
				.setIsBigBlind(true);
		Game.personHashMap.get(Integer.valueOf(bigBlind[0])).setBet(
				Integer.valueOf(bigBlind[1]));

		if (msgSection.length != 1) {
			String[] smallBlind = stringList.get(1);
			competition.setSmallBlind(Integer.valueOf(smallBlind[0]));
			Game.personHashMap.get(Integer.valueOf(smallBlind[0]))
					.setIsSmallBlind(true);
			Game.personHashMap.get(Integer.valueOf(smallBlind[0])).setBet(
					Integer.valueOf(bigBlind[1]));
		}

		// test函数
		// MsgTest test = new MsgTest();
		// test.blindMsgTest();

		 } catch (Exception e) {
		 // TODO: handle exception
		 WritetoFile.getInstance(Game.my_id).writeMsg(e.toString());
		 }
	}
}
