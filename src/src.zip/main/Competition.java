package main;

import java.util.ArrayList;
//比赛信息
public class Competition {
	
	private static Object object = new Object();
	// 回合数
	private int handcount = 1;
	// 庄家
	private int button = 0;
	// 大盲注
	private int bigBlind = 0;
	// 小盲注
	private int smallBlind = 0;
	// pot
	private int pot = 0;
	// person count
	private int personCount = 0;

	private ArrayList<Card> flopCards = new ArrayList<Card>();
	private ArrayList<Card> turnCards = new ArrayList<Card>();
	private ArrayList<Card> riverCards = new ArrayList<Card>();

	public void clearCompetitionMsg() {
		handcount = 0;
		button = 0;
		bigBlind = 0;
		smallBlind = 0;
		pot = 0;
		personCount = 0;
		flopCards.clear();
		turnCards.clear();
		riverCards.clear();
	}

	public ArrayList<Card> getRiverCards() {
		return riverCards;
	}

	public void setRiverCards(ArrayList<Card> riverCards) {
		this.riverCards = riverCards;
	}

	public ArrayList<Card> getTurnCards() {
		return turnCards;
	}

	public void setTurnCards(ArrayList<Card> turnCards) {
		this.turnCards = turnCards;
	}

	public ArrayList<Card> getFlopCards() {
		return flopCards;
	}

	public void setFlopCards(ArrayList<Card> flopCards) {
		this.flopCards = flopCards;
	}

	private static Competition competition = null;

	private Competition() {
		// TODO Auto-generated constructor stub
	}

	public static Competition getInstance() {
		if (competition == null) {
			synchronized (object) {
				if (competition == null) {
					competition = new Competition();
				}
			}
		}
		return competition;
	}

	public int getPersonCount() {
		return personCount;
	}

	public void setPersonCount(int personCount) {
		this.personCount = personCount;
	}

	public int getPot() {
		return pot;
	}

	public void setPot(int pot) {
		this.pot = pot;
	}

	public int getHandcount() {
		return handcount;
	}

	public void setHandcount(int handcount) {
		this.handcount = handcount + 1;
	}

	public void setButton(int button) {
		this.button = button;
	}

	public int getButton() {
		return button;
	}

	public int getBigBlind() {
		return bigBlind;
	}

	public void setBigBlind(int bigBlind) {
		this.bigBlind = bigBlind;
	}

	public int getSmallBlind() {
		return smallBlind;
	}

	public void setSmallBlind(int smallBlind) {
		this.smallBlind = smallBlind;
	}

}
