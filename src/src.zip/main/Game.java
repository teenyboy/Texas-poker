package main;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.util.HashMap;
import java.util.Map;

import util.Time;
import util.WritetoFile;
import msgtool.MsgHandler;
import msgtool.MsgUtil;

public class Game {

	private final static String ENCODERMODE = "US-ASCII";
	private final static int BUFFER_SIZE = 1024 * 1024;
	private final static char[] buffer = new char[BUFFER_SIZE];

	static String server_ip = new String();
	static int server_port;
	static String my_ip;
	static int my_port;
	public static int my_id;

	private static WritetoFile writetoFile;
	private static MsgHandler msgHandler;
	private static String msg;

	public static Person player = new Person();
	public static Map<Integer, Person> personHashMap = new HashMap<Integer, Person>();
	public static Map<Integer, Integer> personStationHashMap = new HashMap<Integer, Integer>();

	public static DataOutputStream outData;

	public static void main(String[] args) {
		Socket socket;
		msgHandler = MsgHandler.getInstance();

		MsgUtil msgUtil = new MsgUtil();

		if (args.length < 6) {
			server_ip = args[0];
			server_port = Integer.valueOf(args[1]);
			my_ip = args[2];
			my_port = Integer.valueOf(args[3]);
			my_id = Integer.valueOf(args[4]);
		}

		System.out.println("server_ip:  " + server_ip);
		System.out.println("server_port:  " + server_port);
		System.out.println("my_ip:  " + my_ip);
		System.out.println("my_port:  " + my_port);
		System.out.println("my_id:  " + my_id);

		player.setPid(my_id);

		try {
			writetoFile = WritetoFile.getInstance(my_id);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		msg = "-----" + Time.getTime() + "-----" + "\r\n";
		writetoFile.writeMsg(msg);

		try {
			socket = new Socket();
			// socket.setSoTimeout(10000);
			SocketAddress localAddress = new InetSocketAddress(my_ip, my_port);
			SocketAddress serverAddress = new InetSocketAddress(server_ip,
					server_port);
			socket.bind(localAddress);
			socket.connect(serverAddress);

			InputStream in = socket.getInputStream();
			OutputStream out = socket.getOutputStream();

			msg = "reg: " + my_id + " wang" + "need_notify" + " \n";
			byte[] register = msgUtil.toSocket(msg);
			outData = new DataOutputStream(out);
			outData.write(register);
			outData.flush();

			// writetoFile.writeMsg(msg);

			BufferedReader br = new BufferedReader(new InputStreamReader(in,
					ENCODERMODE));

			while (true) {

				msg = "-----" + Time.getTime() + "-----" + "\r\n";
				writetoFile.writeMsg(msg);

				msg = null;
				int len = 0;
				len = br.read(buffer);
				if (len != -1) {
					msg = String.valueOf(buffer, 0, len);
					writetoFile.writeMsg(msg);
					// 消息处理
					msgHandler.setMsg(msg);
				}

				if (msg == null) {
					break;
				}
			}
			outData.close();
			socket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			WritetoFile.getInstance(Game.my_id).writeMsg(
					"Game 120 " + e.toString());
		}
	}
}
