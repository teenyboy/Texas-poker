package util;

public interface PersonInterface {

}
