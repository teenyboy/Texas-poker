package util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

public class WritetoFile {

	public static Object obj = new Object();
	private static String pathName = "/home/game/game/works/target/log/";
	// private static String pathName = "D:\\WorkHouse\\demo\\test\\log\\";
	private File logFlie;
	private static WritetoFile writetoFile = null;
	private FileWriter fileWriter;

	private WritetoFile(int id) throws IOException {
		// TODO Auto-generated constructor stub
		File logFileDir = new File(pathName);
		if (!logFileDir.isDirectory())
			logFileDir.mkdir();
		pathName = pathName + String.valueOf(id) + ".txt";
		logFlie = new File(pathName);
		if (!logFlie.exists()) {
			logFlie.createNewFile();
		}
		logFlie.setWritable(true);
		fileWriter = new FileWriter(logFlie, true);
	}

	public static WritetoFile getInstance(int id) {
		if (writetoFile == null) {
			synchronized (obj) {
				if (writetoFile == null)
					try {
						writetoFile = new WritetoFile(id);
					} catch (FileNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
		}
		return writetoFile;
	}

	public void writeMsg(String msg) {
		try {
			fileWriter.append(msg);
			fileWriter.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
