package util;

import java.util.HashMap;

public class ProbilityTable {

	public static HashMap<String, Integer> straightFlushTable = new HashMap<String, Integer>();
	public static HashMap<String, Integer> fourTable = new HashMap<String, Integer>();
	public static HashMap<String, Integer> fullHouseTable = new HashMap<String, Integer>();
	public static HashMap<String, Integer> flushTable = new HashMap<String, Integer>();
	public static HashMap<String, Integer> straightTable = new HashMap<String, Integer>();
	public static HashMap<String, Integer> threeTable = new HashMap<String, Integer>();
	public static HashMap<String, Integer> twoTable = new HashMap<String, Integer>();
	public static HashMap<String, Integer> oneTable = new HashMap<String, Integer>();
	public static HashMap<String, Integer> commonTable = new HashMap<String, Integer>();

	public ProbilityTable() {
		// TODO Auto-generated constructor stub

		straightFlushTable.put("1413121110", 1);
		straightFlushTable.put("131211109", 2);
		straightFlushTable.put("12111098", 3);
		straightFlushTable.put("1110987", 4);
		straightFlushTable.put("109876", 5);
		straightFlushTable.put("98765", 6);
		straightFlushTable.put("87654", 7);
		straightFlushTable.put("76543", 8);
		straightFlushTable.put("65432", 9);
		straightFlushTable.put("54321", 10);

		fourTable.put("1414141413", 11);
		fourTable.put("1414141412", 12);
		fourTable.put("1414141411", 13);
		fourTable.put("1414141410", 14);
		fourTable.put("141414149", 15);
		fourTable.put("141414148", 16);
		fourTable.put("141414147", 17);
		fourTable.put("141414146", 18);
		fourTable.put("141414145", 19);
		fourTable.put("141414144", 20);
		fourTable.put("141414143", 21);
		fourTable.put("141414142", 22);

		fourTable.put("1313131314", 23);
		fourTable.put("1313131312", 24);
		fourTable.put("1313131311", 25);
		fourTable.put("1313131310", 26);
		fourTable.put("131313139", 27);
		fourTable.put("131313138", 28);
		fourTable.put("131313137", 29);
		fourTable.put("131313136", 30);
		fourTable.put("131313135", 31);
		fourTable.put("131313134", 32);
		fourTable.put("131313133", 33);
		fourTable.put("131313132", 34);

		fourTable.put("1212121214", 35);
		fourTable.put("1212121213", 36);
		fourTable.put("1212121211", 37);
		fourTable.put("1212121210", 38);
		fourTable.put("121212129", 39);
		fourTable.put("121212128", 40);
		fourTable.put("121212127", 41);
		fourTable.put("121212126", 42);
		fourTable.put("121212125", 43);
		fourTable.put("121212124", 44);
		fourTable.put("121212123", 45);
		fourTable.put("121212122", 46);

		fourTable.put("1111111114", 47);
		fourTable.put("1111111113", 48);
		fourTable.put("1111111112", 49);
		fourTable.put("1111111110", 50);
		fourTable.put("111111119", 51);
		fourTable.put("111111118", 52);
		fourTable.put("111111117", 53);
		fourTable.put("111111116", 54);
		fourTable.put("111111115", 55);
		fourTable.put("111111114", 56);
		fourTable.put("111111113", 57);
		fourTable.put("111111112", 58);

		fourTable.put("1010101014", 59);
		fourTable.put("1010101013", 60);
		fourTable.put("1010101012", 61);
		fourTable.put("1010101011", 62);
		fourTable.put("101010109", 63);
		fourTable.put("101010108", 64);
		fourTable.put("101010107", 65);
		fourTable.put("101010106", 66);
		fourTable.put("101010105", 67);
		fourTable.put("101010104", 68);
		fourTable.put("101010103", 69);
		fourTable.put("101010102", 70);

		fourTable.put("999914", 71);
		fourTable.put("999913", 72);
		fourTable.put("999912", 73);
		fourTable.put("999911", 74);
		fourTable.put("999910", 75);
		fourTable.put("99998", 76);
		fourTable.put("99997", 77);
		fourTable.put("99996", 78);
		fourTable.put("99995", 79);
		fourTable.put("99994", 80);
		fourTable.put("99993", 81);
		fourTable.put("99992", 82);

		fourTable.put("888814", 83);
		fourTable.put("888813", 84);
		fourTable.put("888812", 85);
		fourTable.put("888811", 86);
		fourTable.put("888810", 87);
		fourTable.put("88889", 88);
		fourTable.put("88887", 89);
		fourTable.put("88886", 90);
		fourTable.put("88885", 91);
		fourTable.put("88884", 92);
		fourTable.put("88883", 93);
		fourTable.put("88882", 94);

		fourTable.put("777714", 95);
		fourTable.put("777713", 96);
		fourTable.put("777712", 97);
		fourTable.put("777711", 98);
		fourTable.put("777710", 99);
		fourTable.put("77779", 100);
		fourTable.put("77778", 101);
		fourTable.put("77776", 102);
		fourTable.put("77775", 103);
		fourTable.put("77774", 104);
		fourTable.put("77773", 105);
		fourTable.put("77772", 106);

		fourTable.put("666614", 107);
		fourTable.put("666613", 108);
		fourTable.put("666612", 109);
		fourTable.put("666611", 110);
		fourTable.put("666610", 111);
		fourTable.put("66669", 112);
		fourTable.put("66668", 113);
		fourTable.put("66667", 114);
		fourTable.put("66665", 115);
		fourTable.put("66664", 116);
		fourTable.put("66663", 117);
		fourTable.put("66662", 118);

		fourTable.put("555514", 119);
		fourTable.put("555513", 120);
		fourTable.put("555512", 121);
		fourTable.put("555511", 122);
		fourTable.put("555510", 123);
		fourTable.put("55559", 124);
		fourTable.put("55558", 125);
		fourTable.put("55557", 126);
		fourTable.put("55556", 127);
		fourTable.put("55554", 128);
		fourTable.put("55553", 129);
		fourTable.put("55552", 130);

		fourTable.put("444414", 131);
		fourTable.put("444413", 132);
		fourTable.put("444412", 133);
		fourTable.put("444411", 134);
		fourTable.put("444410", 135);
		fourTable.put("44449", 136);
		fourTable.put("44448", 137);
		fourTable.put("44447", 138);
		fourTable.put("44446", 139);
		fourTable.put("44445", 140);
		fourTable.put("44443", 141);
		fourTable.put("44442", 142);

		fourTable.put("333314", 143);
		fourTable.put("333313", 144);
		fourTable.put("333312", 145);
		fourTable.put("333311", 146);
		fourTable.put("333310", 147);
		fourTable.put("33339", 148);
		fourTable.put("33338", 149);
		fourTable.put("33337", 150);
		fourTable.put("33336", 151);
		fourTable.put("33335", 152);
		fourTable.put("33334", 153);
		fourTable.put("33332", 154);

		fourTable.put("222214", 155);
		fourTable.put("222213", 156);
		fourTable.put("222212", 157);
		fourTable.put("222211", 158);
		fourTable.put("222210", 159);
		fourTable.put("22229", 160);
		fourTable.put("22228", 161);
		fourTable.put("22227", 162);
		fourTable.put("22226", 163);
		fourTable.put("22225", 164);
		fourTable.put("22224", 165);
		fourTable.put("22223", 166);

		
		threeTable.put("1414141313", 167);
		threeTable.put("1414141212", 168);
		threeTable.put("1414141111", 169);
		threeTable.put("1414141010", 170);
		threeTable.put("14141499", 171);
		threeTable.put("14141488", 172);
		threeTable.put("14141477", 173);
		threeTable.put("14141466", 174);
		threeTable.put("14141455", 175);
		threeTable.put("14141444", 176);
		threeTable.put("14141433", 177);
		threeTable.put("14141422", 178);

		threeTable.put("1313131414", 179);
		threeTable.put("1313131212", 180);
		threeTable.put("1313131111", 181);
		threeTable.put("1313131010", 182);
		threeTable.put("13131399", 183);
		threeTable.put("13131388", 184);
		threeTable.put("13131377", 185);
		threeTable.put("13131366", 186);
		threeTable.put("13131355", 187);
		threeTable.put("13131344", 188);
		threeTable.put("13131333", 189);
		threeTable.put("13131322", 190);

		threeTable.put("1212121414", 191);
		threeTable.put("1212121313", 192);
		threeTable.put("1212121111", 193);
		threeTable.put("1212121010", 194);
		threeTable.put("12121299", 195);
		threeTable.put("12121288", 196);
		threeTable.put("12121277", 197);
		threeTable.put("12121266", 198);
		threeTable.put("12121255", 199);
		threeTable.put("12121244", 200);
		threeTable.put("12121233", 201);
		threeTable.put("12121222", 202);

		threeTable.put("1111111114", 147);
		threeTable.put("1111111113", 148);
		threeTable.put("1111111112", 149);
		threeTable.put("1111111110", 150);
		threeTable.put("111111119", 151);
		threeTable.put("111111118", 152);
		threeTable.put("111111117", 153);
		threeTable.put("111111116", 154);
		threeTable.put("111111115", 155);
		threeTable.put("111111114", 156);
		threeTable.put("111111113", 157);
		threeTable.put("111111112", 58);

		threeTable.put("1010101014", 59);
		threeTable.put("1010101013", 60);
		threeTable.put("1010101012", 61);
		threeTable.put("1010101011", 62);
		threeTable.put("101010109", 63);
		threeTable.put("101010108", 64);
		threeTable.put("101010107", 65);
		threeTable.put("101010106", 66);
		threeTable.put("101010105", 67);
		threeTable.put("101010104", 68);
		threeTable.put("101010103", 69);
		threeTable.put("101010102", 70);

		threeTable.put("999914", 71);
		threeTable.put("999913", 72);
		threeTable.put("999912", 73);
		threeTable.put("999911", 74);
		threeTable.put("999910", 75);
		threeTable.put("99998", 76);
		threeTable.put("99997", 77);
		threeTable.put("99996", 78);
		threeTable.put("99995", 79);
		threeTable.put("99994", 80);
		threeTable.put("99993", 81);
		threeTable.put("99992", 82);

		threeTable.put("888814", 83);
		threeTable.put("888813", 84);
		threeTable.put("888812", 85);
		threeTable.put("888811", 86);
		threeTable.put("888810", 87);
		threeTable.put("88889", 88);
		threeTable.put("88887", 89);
		threeTable.put("88886", 90);
		threeTable.put("88885", 91);
		threeTable.put("88884", 92);
		threeTable.put("88883", 93);
		threeTable.put("88882", 94);

		threeTable.put("777714", 95);
		threeTable.put("777713", 96);
		threeTable.put("777712", 97);
		threeTable.put("777711", 98);
		threeTable.put("777710", 99);
		threeTable.put("77779", 100);
		threeTable.put("77778", 101);
		threeTable.put("77776", 102);
		threeTable.put("77775", 103);
		threeTable.put("77774", 104);
		threeTable.put("77773", 105);
		threeTable.put("77772", 106);

		threeTable.put("666614", 107);
		threeTable.put("666613", 108);
		threeTable.put("666612", 109);
		threeTable.put("666611", 110);
		threeTable.put("666610", 111);
		threeTable.put("66669", 112);
		threeTable.put("66668", 113);
		threeTable.put("66667", 114);
		threeTable.put("66665", 115);
		threeTable.put("66664", 116);
		threeTable.put("66663", 117);
		threeTable.put("66662", 118);

		threeTable.put("555514", 119);
		threeTable.put("555513", 120);
		threeTable.put("555512", 121);
		threeTable.put("555511", 122);
		threeTable.put("555510", 123);
		threeTable.put("55559", 124);
		threeTable.put("55558", 125);
		threeTable.put("55557", 126);
		threeTable.put("55556", 127);
		threeTable.put("55554", 128);
		threeTable.put("55553", 129);
		threeTable.put("55552", 130);

		threeTable.put("444414", 131);
		threeTable.put("444413", 132);
		threeTable.put("444412", 133);
		threeTable.put("444411", 134);
		threeTable.put("444410", 135);
		threeTable.put("44449", 136);
		threeTable.put("44448", 137);
		threeTable.put("44447", 138);
		threeTable.put("44446", 139);
		threeTable.put("44445", 140);
		threeTable.put("44443", 141);
		threeTable.put("44442", 142);

		threeTable.put("333314", 143);
		threeTable.put("333313", 144);
		threeTable.put("333312", 145);
		threeTable.put("333311", 146);
		threeTable.put("333310", 147);
		threeTable.put("33339", 148);
		threeTable.put("33338", 149);
		threeTable.put("33337", 150);
		threeTable.put("33336", 151);
		threeTable.put("33335", 152);
		threeTable.put("33334", 153);
		threeTable.put("33332", 154);

		threeTable.put("222214", 155);
		threeTable.put("222213", 156);
		threeTable.put("222212", 157);
		threeTable.put("222211", 158);
		threeTable.put("222210", 159);
		threeTable.put("22229", 160);
		threeTable.put("22228", 161);
		threeTable.put("22227", 162);
		threeTable.put("22226", 163);
		threeTable.put("22225", 164);
		threeTable.put("22224", 165);
		threeTable.put("22223", 166);
	}

	public int getStraightFlush(String card) {
		return straightFlushTable.get(card);
	}

	public int getFourFlush(String card) {
		return fourTable.get(card);
	}
}
