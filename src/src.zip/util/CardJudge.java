package util;

import java.util.ArrayList;
import java.util.Arrays;

import main.Card;
import main.Game;

public class CardJudge {

	ArrayList<Card> cards = new ArrayList<Card>();

	public CardJudge(ArrayList<Card> cards) {
		// TODO Auto-generated constructor stub
		this.cards = cards;
	}

	public int getCardJudge() {

		int cardJudge = 0;

		int[] cardPoint = new int[5];
		int[] cardColor = new int[5];

		int[] cardPointNum = new int[5];

		// ArrayList<Integer> cardPoint = new ArrayList<Integer>();
		// ArrayList<Integer> cardColor = new ArrayList<Integer>();

		cardPoint[0] = cards.get(0).getPoint();
		cardPoint[1] = cards.get(1).getPoint();
		cardPoint[2] = cards.get(2).getPoint();
		cardPoint[3] = cards.get(3).getPoint();
		cardPoint[4] = cards.get(4).getPoint();

		cardColor[0] = cards.get(0).getColor();
		cardColor[1] = cards.get(1).getColor();
		cardColor[2] = cards.get(2).getColor();
		cardColor[3] = cards.get(3).getColor();
		cardColor[4] = cards.get(4).getColor();

		String msg = "";
		for (int i = 0; i < cardColor.length; i++) {
			msg = msg + "point :" + cardPoint[i] + "color :" + cardColor[i];
		}
		WritetoFile.getInstance(Game.my_id).writeMsg(msg + "\r\n");

		Arrays.sort(cardPoint);

		if (cardPoint[4] == 14) {
			cardPointNum[0] = 1;
			cardPointNum[1] = cardPoint[0];
			cardPointNum[2] = cardPoint[1];
			cardPointNum[3] = cardPoint[2];
			cardPointNum[4] = cardPoint[3];
		}

		CardSequence cardSequence = new CardSequence();

		if (cardColor[0] == cardColor[1] && cardColor[1] == cardColor[2]
				&& cardColor[2] == cardColor[3] && cardColor[3] == cardColor[4]) {

			if ((cardPoint[0] + 1 == cardPoint[1]
					&& cardPoint[1] + 1 == cardPoint[2]
					&& cardPoint[2] + 1 == cardPoint[3] && cardPoint[3] + 1 == cardPoint[4])
					|| (cardPointNum[0] + 1 == cardPointNum[1]
							&& cardPointNum[1] + 1 == cardPointNum[2]
							&& cardPointNum[2] + 1 == cardPointNum[3] && cardPointNum[3] + 1 == cardPointNum[4])) {

				// 同花顺
				cardSequence.setCardAbility(0);
				// A2345
				if (cardPointNum[0] + 1 == cardPointNum[1]) {
					cardSequence.setCardNum(10);
				}
				// 同花顺筛选
				cardSequence.setCardNum(cardSequence
						.getStraightFlush(cardPoint));

				cardJudge = cardSequence.getCardNum();
			} else {
				// 同花
				cardSequence.setCardAbility(3);
				
				
			}
		}

		return cardJudge;
	}
}
