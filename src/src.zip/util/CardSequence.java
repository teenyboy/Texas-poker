package util;

public class CardSequence {

	public final static int STRAIGHT_FLUSH = 0;
	public final static int FOUR_OF_A_KIND = 1;
	public final static int FULL_HOUSE = 2;
	public final static int FLUSH = 3;
	public final static int STRAIGHT = 4;
	public final static int THREE_OF_A_KIND = 5;
	public final static int TWO_PAIR = 6;
	public final static int ONE_PAIR = 7;
	public final static int HIGH_CARD = 8;

	private int cardAbility = 0;
	private int cardNum = 0;

	public int getCardNum() {
		return cardNum;
	}

	public void setCardNum(int cardNum) {
		this.cardNum = cardNum;
	}

	public int getCardAbility() {
		return cardAbility;
	}

	public void setCardAbility(int cardAbility) {
		this.cardAbility = cardAbility;
	}

	// 同花顺筛选
	public int getStraightFlush(int[] num) {
		return 13 - num[2];
	}

	// 同花筛选
	public int getFlush(int[] num) {
		
		return 0;
	}
}
