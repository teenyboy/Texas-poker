package msgtool;

import java.io.IOException;

import core.Core;
import main.Competition;
import main.Game;
import msgcontext.BlindMsg;
import msgcontext.FlopMsg;
import msgcontext.HoldMsg;
import msgcontext.InquireMsg;
import msgcontext.NotifyMsg;
import msgcontext.PotWinMsg;
import msgcontext.RiverMsg;
import msgcontext.SeatMsg;
import msgcontext.ShowDwonMsg;
import msgcontext.TurnMsg;
import util.WritetoFile;

public class MsgHandler implements MsgInterface {

	private static MsgHandler msgHandler = null;
	private int handCount;

	private MsgHandler() {
		// TODO Auto-generated constructor stub
	}
	//消息解析
	public static MsgHandler getInstance() {
		if (msgHandler == null) {
			synchronized (WritetoFile.obj) {
				if (msgHandler == null)
					msgHandler = new MsgHandler();
			}
		}
		return msgHandler;
	}

	public void setMsg(String msg) {
		dealMsg(msg);
	}

	private void dealMsg(String msg) {
		int first = msg.indexOf("/");
		if (first != -1) {
			if (msg.subSequence(0, first).equals("seat")) {
				// seat消息
				int seatEnd = msg.indexOf("/", first + 1);
				String seatMsg = msg.substring(first + 3, seatEnd);
				getSeatMsg(seatMsg);// 写入seatMsg信息

				int blindFirst = msg.indexOf("/", seatEnd + 2);
				if (blindFirst != -1) {
					int blindEnd = msg.indexOf("/", blindFirst + 1);
					String blindMsg = msg.substring(blindFirst + 3, blindEnd);

					getBlindMsg(blindMsg);// 写入blindMsg信息

					int holdFirst = msg.indexOf("/", blindEnd + 2);
					if (holdFirst != -1) {
						int holdEnd = msg.indexOf("/", holdFirst + 1);
						String holdMsg = msg.substring(holdFirst + 3, holdEnd);

						getHoldCardsMsg(holdMsg);// 写入blindMsg信息

						int inquireFirst = msg.indexOf("/", holdEnd + 2);
						if (inquireFirst != -1) {
							int inquireEnd = msg.indexOf("/", inquireFirst + 1);
							String inquireMsg = msg.substring(inquireFirst + 3,
									inquireEnd);

							getInquireMsg(inquireMsg);// 写入blindMsg信息
						}
					}
				}
			} else if (msg.subSequence(0, first).equals("blind")) {
				// hold消息
				int blindEnd = msg.indexOf("/", first + 1);
				String blindMsg = msg.substring(first + 3, blindEnd);
				getBlindMsg(blindMsg);// 写入blindMsg信息

				int holdFirst = msg.indexOf("/", blindEnd + 2);
				if (holdFirst != -1) {
					int holdEnd = msg.indexOf("/", holdFirst + 1);
					String holdMsg = msg.substring(holdFirst + 3, holdEnd);

					getHoldCardsMsg(holdMsg);// 写入blindMsg信息

					int inquireFirst = msg.indexOf("/", holdEnd + 2);
					if (inquireFirst != -1) {
						int inquireEnd = msg.indexOf("/", inquireFirst + 1);
						String inquireMsg = msg.substring(inquireFirst + 3,
								inquireEnd);

						getInquireMsg(inquireMsg);// 写入blindMsg信息
					}
				}

			} else if (msg.subSequence(0, first).equals("hold")) {
				// hold消息
				int holdEnd = msg.indexOf("/", first + 1);
				String holdMsg = msg.substring(first + 3, holdEnd);
				getHoldCardsMsg(holdMsg);// 写入holdMsg信息

				int inquireFirst = msg.indexOf("/", holdEnd + 2);
				if (inquireFirst != -1) {
					int inquireEnd = msg.indexOf("/", inquireFirst + 1);
					String inquireMsg = msg.substring(inquireFirst + 3,
							inquireEnd);

					getInquireMsg(inquireMsg);// 写入blindMsg信息
					// WritetoFile.getInstance(Game.my_id).writeMsg(inquireMsg);
				}

			} else if (msg.subSequence(0, first).equals("inquire")) {
				// inquire消息
				int inquireEnd = msg.indexOf("/", first + 1);
				String inquireMsg = msg.substring(first + 3, inquireEnd);
				getInquireMsg(inquireMsg);// 写入inquireMsg信息
			} else if (msg.subSequence(0, first).equals("flop")) {
				// flop消息
				int flopEnd = msg.indexOf("/", first + 1);
				String flopMsg = msg.substring(first + 3, flopEnd);
				getFlopMsg(flopMsg);// 写入flopMsg信息

				int turnFirst = msg.indexOf("/", flopEnd + 2);
				if (turnFirst != -1) {
					int turnEnd = msg.indexOf("/", turnFirst + 1);
					String turnMsg = msg.substring(turnFirst + 3, turnEnd);

					getTurnMsg(turnMsg);// 写入blindMsg信息
					// WritetoFile.getInstance(Game.my_id).writeMsg(turnMsg);

					int riverFirst = msg.indexOf("/", turnEnd + 2);
					if (riverFirst != -1) {
						int riverEnd = msg.indexOf("/", riverFirst + 1);
						String riverMsg = msg.substring(riverFirst + 3,
								riverEnd);

						getRiverMsg(riverMsg);// 写入blindMsg信息
						// WritetoFile.getInstance(Game.my_id).writeMsg(riverMsg);

						int showdownFirst = msg.indexOf("/", riverEnd + 2);
						if (showdownFirst != -1) {

							int commonFirst = msg.indexOf("/",
									showdownFirst + 2);
							int commonEnd = msg.indexOf("/", commonFirst + 2);
							int showDownEnd = msg.indexOf("/", commonEnd + 2);
							String showDownMsg = msg.substring(commonEnd + 9,
									showDownEnd);

							getShowDownMsg(showDownMsg);// 写入blindMsg信息
							// WritetoFile.getInstance(Game.my_id).writeMsg(showdownMsg);

							int potWinFirst = msg.indexOf("/", showDownEnd + 2);
							if (potWinFirst != -1) {
								int potWinEnd = msg.indexOf("/",
										potWinFirst + 1);
								String potWinMsg = msg.substring(
										potWinFirst + 3, potWinEnd);

								getPotWinMsg(potWinMsg);
								// 写入blindMsg信息
								// WritetoFile.getInstance(Game.my_id).writeMsg(potWinMsg);

								int seatFirst = msg.indexOf("/", potWinEnd + 2);
								if (seatFirst != -1) {
									int seatEnd = msg.indexOf("/",
											seatFirst + 1);
									String seatMsg = msg.substring(
											seatFirst + 3, seatEnd);

									getSeatMsg(seatMsg);
									// 写入blindMsg信息
									// WritetoFile.getInstance(Game.my_id).writeMsg(seatMsg);

									int blindFirst = msg.indexOf("/",
											seatEnd + 2);
									if (blindFirst != -1) {
										int blindEnd = msg.indexOf("/",
												blindFirst + 1);
										String blindMsg = msg.substring(
												blindFirst + 3, blindEnd);

										getBlindMsg(blindMsg);
										// 写入blindMsg信息
										// WritetoFile.getInstance(Game.my_id).writeMsg(blindMsg);

										int holdFirst = msg.indexOf("/",
												blindEnd + 2);
										if (holdFirst != -1) {
											int holdEnd = msg.indexOf("/",
													holdFirst + 1);
											String holdMsg = msg.substring(
													holdFirst + 3, holdEnd);

											getHoldCardsMsg(holdMsg);
											// 写入blindMsg信息
											// WritetoFile.getInstance(Game.my_id).writeMsg(holdMsg);
										}
									}
								}
							}
						}
					}
				}
			} else if (msg.subSequence(0, first).equals("turn")) {
				// turn消息
				int turnEnd = msg.indexOf("/", first + 1);
				String turnMsg = msg.substring(first + 3, turnEnd);
				getTurnMsg(turnMsg);// 写入turnMsg信息

				int riverFirst = msg.indexOf("/", turnEnd + 2);
				if (riverFirst != -1) {
					int riverEnd = msg.indexOf("/", riverFirst + 1);
					String riverMsg = msg.substring(riverFirst + 3, riverEnd);

					getRiverMsg(riverMsg);// 写入blindMsg信息
					// WritetoFile.getInstance(Game.my_id).writeMsg(riverMsg);

					int showdownFirst = msg.indexOf("/", riverEnd + 2);
					if (showdownFirst != -1) {

						int commonFirst = msg.indexOf("/", showdownFirst + 2);
						int commonEnd = msg.indexOf("/", commonFirst + 2);
						int showDownEnd = msg.indexOf("/", commonEnd + 2);
						String showDownMsg = msg.substring(commonEnd + 9,
								showDownEnd);

						getShowDownMsg(showDownMsg);// 写入blindMsg信息
						// WritetoFile.getInstance(Game.my_id).writeMsg(showdownMsg);

						int potWinFirst = msg.indexOf("/", showDownEnd + 2);
						if (potWinFirst != -1) {
							int potWinEnd = msg.indexOf("/", potWinFirst + 1);
							String potWinMsg = msg.substring(potWinFirst + 3,
									potWinEnd);

							getPotWinMsg(potWinMsg);
							// 写入blindMsg信息
							// WritetoFile.getInstance(Game.my_id).writeMsg(potWinMsg);

							int seatFirst = msg.indexOf("/", potWinEnd + 2);
							if (seatFirst != -1) {
								int seatEnd = msg.indexOf("/", seatFirst + 1);
								String seatMsg = msg.substring(seatFirst + 3,
										seatEnd);

								getSeatMsg(seatMsg);
								// 写入blindMsg信息
								// WritetoFile.getInstance(Game.my_id).writeMsg(seatMsg);

								int blindFirst = msg.indexOf("/", seatEnd + 2);
								if (blindFirst != -1) {
									int blindEnd = msg.indexOf("/",
											blindFirst + 1);
									String blindMsg = msg.substring(
											blindFirst + 3, blindEnd);

									getBlindMsg(blindMsg);
									// 写入blindMsg信息
									// WritetoFile.getInstance(Game.my_id).writeMsg(blindMsg);

									int holdFirst = msg.indexOf("/",
											blindEnd + 2);
									if (holdFirst != -1) {
										int holdEnd = msg.indexOf("/",
												holdFirst + 1);
										String holdMsg = msg.substring(
												holdFirst + 3, holdEnd);

										getHoldCardsMsg(holdMsg);
										// 写入blindMsg信息
										// WritetoFile.getInstance(Game.my_id).writeMsg(holdMsg);
									}
								}
							}
						}
					}
				}
			} else if (msg.subSequence(0, first).equals("river")) {
				// river消息
				int riverEnd = msg.indexOf("/", first + 1);
				String riverMsg = msg.substring(first + 3, riverEnd);
				getRiverMsg(riverMsg);// 写入riverMsg信息

				int showdownFirst = msg.indexOf("/", riverEnd + 2);
				if (showdownFirst != -1) {

					int commonFirst = msg.indexOf("/", showdownFirst + 2);
					int commonEnd = msg.indexOf("/", commonFirst + 2);
					int showDownEnd = msg.indexOf("/", commonEnd + 2);
					String showDownMsg = msg.substring(commonEnd + 9,
							showDownEnd);

					getShowDownMsg(showDownMsg);// 写入blindMsg信息
					// WritetoFile.getInstance(Game.my_id).writeMsg(showdownMsg);

					int potWinFirst = msg.indexOf("/", showDownEnd + 2);
					if (potWinFirst != -1) {
						int potWinEnd = msg.indexOf("/", potWinFirst + 1);
						String potWinMsg = msg.substring(potWinFirst + 3,
								potWinEnd);

						getPotWinMsg(potWinMsg);
						// 写入blindMsg信息
						// WritetoFile.getInstance(Game.my_id).writeMsg(potWinMsg);

						int seatFirst = msg.indexOf("/", potWinEnd + 2);
						if (seatFirst != -1) {
							int seatEnd = msg.indexOf("/", seatFirst + 1);
							String seatMsg = msg.substring(seatFirst + 3,
									seatEnd);

							getSeatMsg(seatMsg);
							// 写入blindMsg信息
							// WritetoFile.getInstance(Game.my_id).writeMsg(seatMsg);

							int blindFirst = msg.indexOf("/", seatEnd + 2);
							if (blindFirst != -1) {
								int blindEnd = msg.indexOf("/", blindFirst + 1);
								String blindMsg = msg.substring(blindFirst + 3,
										blindEnd);

								getBlindMsg(blindMsg);
								// 写入blindMsg信息
								// WritetoFile.getInstance(Game.my_id).writeMsg(blindMsg);

								int holdFirst = msg.indexOf("/", blindEnd + 2);
								if (holdFirst != -1) {
									int holdEnd = msg.indexOf("/",
											holdFirst + 1);
									String holdMsg = msg.substring(
											holdFirst + 3, holdEnd);

									getHoldCardsMsg(holdMsg);
									// 写入blindMsg信息
									// WritetoFile.getInstance(Game.my_id).writeMsg(holdMsg);
								}
							}
						}
					}
				}
			} else if (msg.subSequence(0, first).equals("showdown")) {
				// Shutdown消息
				int commonFirst = msg.indexOf("/", first + 2);
				int commonEnd = msg.indexOf("/", commonFirst + 2);
				int showDownEnd = msg.lastIndexOf("/");
				String showDownMsg = msg.substring(commonEnd + 9, showDownEnd);

				getShowDownMsg(showDownMsg);// 写入showDownMsg信息

				int potWinFirst = msg.indexOf("/", showDownEnd + 2);
				if (potWinFirst != -1) {
					int potWinEnd = msg.indexOf("/", potWinFirst + 1);
					String potWinMsg = msg
							.substring(potWinFirst + 3, potWinEnd);

					getPotWinMsg(potWinMsg);
					// 写入blindMsg信息
					// WritetoFile.getInstance(Game.my_id).writeMsg(potWinMsg);

					int seatFirst = msg.indexOf("/", potWinEnd + 2);
					if (seatFirst != -1) {
						int seatEnd = msg.indexOf("/", seatFirst + 1);
						String seatMsg = msg.substring(seatFirst + 3, seatEnd);

						getSeatMsg(seatMsg);
						// 写入blindMsg信息
						// WritetoFile.getInstance(Game.my_id).writeMsg(seatMsg);

						int blindFirst = msg.indexOf("/", seatEnd + 2);
						if (blindFirst != -1) {
							int blindEnd = msg.indexOf("/", blindFirst + 1);
							String blindMsg = msg.substring(blindFirst + 3,
									blindEnd);

							getBlindMsg(blindMsg);
							// 写入blindMsg信息
							// WritetoFile.getInstance(Game.my_id).writeMsg(blindMsg);

							int holdFirst = msg.indexOf("/", blindEnd + 2);
							if (holdFirst != -1) {
								int holdEnd = msg.indexOf("/", holdFirst + 1);
								String holdMsg = msg.substring(holdFirst + 3,
										holdEnd);

								getHoldCardsMsg(holdMsg);
								// 写入blindMsg信息
								// WritetoFile.getInstance(Game.my_id).writeMsg(holdMsg);
							}

						}
					}
				}
			} else if (msg.subSequence(0, first).equals("pot-win")) {
				// pot-win消息
				int potWinEnd = msg.indexOf("/", first + 1);
				String potWinMsg = msg.substring(first + 3, potWinEnd);
				getPotWinMsg(potWinMsg);// 写入potWinMsg信息

				int seatFirst = msg.indexOf("/", potWinEnd + 2);
				if (seatFirst != -1) {
					int seatEnd = msg.indexOf("/", seatFirst + 1);
					String seatMsg = msg.substring(seatFirst + 3, seatEnd);

					getSeatMsg(seatMsg);
					// 写入blindMsg信息
					// WritetoFile.getInstance(Game.my_id).writeMsg(seatMsg);

					int blindFirst = msg.indexOf("/", seatEnd + 2);
					if (blindFirst != -1) {
						int blindEnd = msg.indexOf("/", blindFirst + 1);
						String blindMsg = msg.substring(blindFirst + 3,
								blindEnd);

						getBlindMsg(blindMsg);
						// 写入blindMsg信息
						// WritetoFile.getInstance(Game.my_id).writeMsg(blindMsg);

						int holdFirst = msg.indexOf("/", blindEnd + 2);
						if (holdFirst != -1) {
							int holdEnd = msg.indexOf("/", holdFirst + 1);
							String holdMsg = msg.substring(holdFirst + 3,
									holdEnd);

							getHoldCardsMsg(holdMsg);
							// 写入blindMsg信息
							// WritetoFile.getInstance(Game.my_id).writeMsg(holdMsg);
						}
					}
				}
			} else if (msg.subSequence(0, first).equals("notify")) {
				// notify消息
				int notifyEnd = msg.indexOf("/", first + 1);
				String notifyMsg = msg.substring(first + 3, notifyEnd);
				getNotifyMsg(notifyMsg);// 写入notifyMsg信息
			}
		}
	}

	@Override
	public void getSeatMsg(String msg) {
		// TODO Auto-generated method stub
		handCount = Competition.getInstance().getHandcount();

		WritetoFile.getInstance(Game.my_id).writeMsg(
				"\r\n" + "---------------------the hand is "
						+ String.valueOf(handCount) + "---------------------"
						+ "\r\n" + "--------SeatMsg--------" + "\r\n");

		SeatMsg seatMsg = new SeatMsg();
		seatMsg.getMsg(msg);
	}

	@Override
	public void getBlindMsg(String msg) {
		// TODO Auto-generated method stub
		WritetoFile.getInstance(Game.my_id).writeMsg(
				"--------BlindMsg--------" + "\r\n");
		BlindMsg blindMsg = new BlindMsg();
		blindMsg.getMsg(msg);
	}

	@Override
	public void getHoldCardsMsg(String msg) {
		// TODO Auto-generated method stub
		WritetoFile.getInstance(Game.my_id).writeMsg(
				"--------HoldMsg--------" + "\r\n");
		HoldMsg holdMsg = new HoldMsg();
		holdMsg.getMsg(msg);
	}

	@Override
	public void getInquireMsg(String msg) {
		// TODO Auto-generated method stub
		WritetoFile.getInstance(Game.my_id).writeMsg(
				"--------InquireMsg--------" + "\r\n");
		InquireMsg inquireMsg = new InquireMsg();
		inquireMsg.getMsg(msg);

		Core msgCore = new Core();
		try {
			msgCore.algorithmCore();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void getFlopMsg(String msg) {
		// TODO Auto-generated method stub
		WritetoFile.getInstance(Game.my_id).writeMsg(
				"--------FlopMsg--------" + "\r\n");
		FlopMsg flopMsg = new FlopMsg();
		flopMsg.getMsg(msg);
	}

	@Override
	public void getTurnMsg(String msg) {
		// TODO Auto-generated method stub
		WritetoFile.getInstance(Game.my_id).writeMsg(
				"--------TurnMsg--------" + "\r\n");
		TurnMsg turnMsg = new TurnMsg();
		turnMsg.getMsg(msg);
	}

	@Override
	public void getRiverMsg(String msg) {
		// TODO Auto-generated method stub
		WritetoFile.getInstance(Game.my_id).writeMsg(
				"--------RiverMsg--------" + "\r\n");
		RiverMsg riverMsg = new RiverMsg();
		riverMsg.getMsg(msg);
	}

	@Override
	public void getShowDownMsg(String msg) {
		// TODO Auto-generated method stub
		WritetoFile.getInstance(Game.my_id).writeMsg(
				"--------ShowDownMsg--------" + "\r\n");
		ShowDwonMsg showDwonMsg = new ShowDwonMsg();
		showDwonMsg.getMsg(msg);
	}

	@Override
	public void getPotWinMsg(String msg) {
		// TODO Auto-generated method stub
		WritetoFile.getInstance(Game.my_id).writeMsg(
				"--------PotWinMsg--------" + "\r\n");
		PotWinMsg potWinMsg = new PotWinMsg();
		potWinMsg.getMsg(msg);

		Competition.getInstance().setHandcount(handCount);
	}

	@Override
	public void getNotifyMsg(String msg) {
		// TODO Auto-generated method stub
		WritetoFile.getInstance(Game.my_id).writeMsg(
				"--------NotifyMsg--------" + "\r\n");
		NotifyMsg notifyMsg = new NotifyMsg();
		notifyMsg.getMsg(msg);
	}

}
