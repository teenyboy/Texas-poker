package msgtool;

public interface MsgFactory {

	public void getMsg(String msg);

}
