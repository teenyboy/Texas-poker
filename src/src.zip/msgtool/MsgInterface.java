package msgtool;

public interface MsgInterface {

	public void getSeatMsg(String msg);

	public void getBlindMsg(String msg);

	public void getHoldCardsMsg(String msg);

	public void getInquireMsg(String msg);

	public void getFlopMsg(String msg);

	public void getTurnMsg(String msg);

	public void getRiverMsg(String msg);

	public void getShowDownMsg(String msg);

	public void getPotWinMsg(String msg);

	public void getNotifyMsg(String msg);
}
