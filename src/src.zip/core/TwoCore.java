package core;

import main.Card;
import main.Competition;
import main.Game;
import main.Person;

public class TwoCore {

	public TwoCore() {
		// TODO Auto-generated constructor stub
	}

	public int getTwoCore() {

		Person player = Game.personHashMap.get(Game.my_id);
		Card card1 = player.getHold().get(0);
		Card card2 = player.getHold().get(1);

		int card1Point = card1.getPoint();
		int card2Point = card2.getPoint();

		int card1Color = card1.getColor();
		int card2Color = card2.getColor();

		int action = 0;

		int bigRaisePersonNum = 0;
		int maxBet = 0;
		int flopPersonNum = 0;
		int doublePersonCount = Competition.getInstance().getPersonCount() / 2;

		try {

			for (int i = 0; i < Game.personHashMap.size(); i++) {
				if (Game.player.getStation() != i) {
					int bet = Game.personHashMap.get(
							Game.personStationHashMap.get(i)).getBet();
					// 下注超过500的人数
					if (bet > 500)
						bigRaisePersonNum++;
					// 目前最大下注，即跟注需要的赌注
					if (bet > maxBet) {
						maxBet = bet;
					}

					if (Game.personHashMap
							.get(Game.personStationHashMap.get(i)).getAction() == 4) {
						flopPersonNum++;
					}

				}
			}

			if ((card1Point == 14 && card2Point == 14)
					|| (card1Point == 13 && card2Point == 13)
					|| (card1Point == 12 && card2Point == 12)
					|| (card1Point == 14 && card2Point == 13 && card1Color == card2Color)
					|| (card1Point == 14 && card2Point == 12 && card1Color == card2Color)) {
				player.setCardAbility(0);

				// 1号位
				if (player.getStation() == 1) {
					action = 2;
				}

				// 2号位
				if (player.getStation() == 2) {
					action = 2;
				}

				// 3号位，如果下注500人数超过4个，则跟牌,否则加注50
				if (player.getStation() == 3) {
					if (bigRaisePersonNum >= doublePersonCount
							|| flopPersonNum >= doublePersonCount) {
						action = 1;
					} else {
						action = 2;
					}
				}

				// 4号位，如果下注500人数超过4个，则跟牌,否则加注50
				if (player.getStation() == 4) {
					if (bigRaisePersonNum >= doublePersonCount
							|| flopPersonNum >= doublePersonCount) {
						action = 1;
					} else {
						action = 2;
					}
				}

				// 5号位，如果下注500人数超过4个，则跟牌,否则加注50
				if (player.getStation() == 5) {
					if (bigRaisePersonNum >= doublePersonCount
							|| flopPersonNum >= doublePersonCount) {
						action = 1;
					} else {
						action = 2;
					}
				}

				// 6号位，如果下注500人数超过4个，则跟牌,否则加注50
				if (player.getStation() == 6) {
					if (bigRaisePersonNum >= doublePersonCount
							|| flopPersonNum >= doublePersonCount) {
						action = 1;
					} else {
						action = 2;
					}
				}

				// 7号位，如果下注500人数超过4个，则跟牌,否则加注50
				if (player.getStation() == 7) {
					if (bigRaisePersonNum >= doublePersonCount
							|| flopPersonNum >= doublePersonCount) {
						action = 1;
					} else {
						action = 2;
					}
				}

				// 8号位，如果下注500人数超过4个，则跟牌,否则加注50
				if (player.getStation() == 8) {
					if (bigRaisePersonNum >= doublePersonCount
							|| flopPersonNum >= doublePersonCount) {
						action = 1;
					} else {
						action = 2;
					}
				}

			} else if ((card1Point == card2Point)
					|| (card1Point == 14 && card2Point == 11 && card1Color == card2Color)
					|| (card1Point == 13 && card2Point == 12 && card1Color == card2Color)
					|| (card1Point == 14 && card2Point == 13)
					|| (card1Point == 14 && card2Point == 12)
					|| (card1Point == 13 && card2Point == 12)) {

				player.setCardAbility(1);

				// 1号位
				if (player.getStation() == 1) {
					action = 2;
				}

				// 2号位
				if (player.getStation() == 2) {
					action = 2;
				}

				// 3号位，如果下注500人数超过4个，则跟牌,否则加注50
				if (player.getStation() == 3) {
					// 小于500可跟
					if (maxBet < 500) {
						action = 1;
					} else {
						action = 4;
					}
				}

				// 4号位情况
				if (player.getStation() == 4) {
					// 小于500可跟
					if (maxBet < 500) {
						action = 1;
					} else {
						action = 4;
					}
				}

				// 5号位，如果下注500人数超过4个，则跟牌,否则加注50
				if (player.getStation() == 5) {
					// 小于500可跟
					if (maxBet < 500) {
						action = 1;
					} else {
						action = 4;
					}
					// if (bigRaisePersonNum > 4) {
					// action = 1;
					// } else {
					// action = 2;
					// }
				}

				// 6号位，如果下注500人数超过4个，则跟牌,否则加注50
				if (player.getStation() == 6) {
					// 小于500可跟
					if (maxBet < 500) {
						action = 1;
					} else {
						action = 4;
					}
					// if (bigRaisePersonNum > 4) {
					// action = 1;
					// } else {
					// action = 2;
					// }
				}

				// 7号位，如果下注500人数超过4个，则跟牌,否则加注50
				if (player.getStation() == 7) {
					// 小于500可跟
					if (maxBet < 500) {
						action = 1;
					} else {
						action = 4;
					}
					// if (bigRaisePersonNum > 4) {
					// action = 1;
					// } else {
					// action = 2;
					// }
				}

				// 8号位，如果下注500人数超过4个，则跟牌,否则加注50
				if (player.getStation() == 8) {
					// 小于500可跟
					if (maxBet < 500) {
						action = 1;
					} else {
						action = 4;
					}
					// if (bigRaisePersonNum > 4) {
					// action = 1;
					// } else {
					// action = 2;
					// }
				}
			} else {
				player.setCardAbility(2);

				// 1号位
				if (player.getStation() == 1) {
					action = 2;
				}

				// 2号位
				if (player.getStation() == 2) {
					action = 2;
				}

				// 3号位，如果下注500人数超过4个，则跟牌,否则加注50
				if (player.getStation() == 3) {
					// 小于500可跟
					if (maxBet > 400) {
						action = 4;
					} else {
						action = 1;
					}
				}

				// 4号位情况
				if (player.getStation() == 4) {
					// 赌注大于200弃牌，否则跟
					if (maxBet > 400) {
						action = 4;
					} else {
						action = 1;
					}
				}

				// 5号位，如果下注500人数超过4个，则跟牌,否则加注50
				if (player.getStation() == 5) {
					if (maxBet > 400) {
						action = 4;
					} else {
						action = 1;
					}
					// if (bigRaisePersonNum > 4) {
					// action = 1;
					// } else {
					// action = 2;
					// }
				}

				// 6号位，如果下注500人数超过4个，则跟牌,否则加注50
				if (player.getStation() == 6) {
					if (maxBet > 400) {
						action = 4;
					} else {
						action = 1;
					}
					// if (bigRaisePersonNum > 4) {
					// action = 1;
					// } else {
					// action = 2;
					// }
				}

				// 7号位，如果下注500人数超过4个，则跟牌,否则加注50
				if (player.getStation() == 7) {
					if (maxBet > 400) {
						action = 4;
					} else {
						action = 1;
					}
					// if (bigRaisePersonNum > 4) {
					// action = 1;
					// } else {
					// action = 2;
					// }
				}

				// 8号位，如果下注500人数超过4个，则跟牌,否则加注50
				if (player.getStation() == 8) {
					if (maxBet > 400) {
						action = 4;
					} else {
						action = 1;
					}
					// if (bigRaisePersonNum > 4) {
					// action = 1;
					// } else {
					// action = 2;
					// }
				}
			}
			// public void getTwoCore() {
			// Person player = Game.personHashMap.get(Game.my_id);
			// Card card1 = player.getHold().get(0);
			// Card card2 = player.getHold().get(1);
			//
			// int card1Point = card1.getPoint();
			// int card2Point = card2.getPoint();
			//
			// int card1Color = card1.getColor();
			// int card2Color = card2.getColor();
			//
			// int personBillNum;
			// int max = 0;
			// if (card1Point > card2Point) {
			// max = card1Point;
			// } else {
			// max = card2Point;
			// }
			//
			// switch (max) {
			// case 1:
			// personBillNum = 10;
			// break;
			// case 13:
			// personBillNum = 8;
			// break;
			// case 12:
			// personBillNum = 7;
			// break;
			// case 11:
			// personBillNum = 6;
			// break;
			// default:
			// personBillNum = max / 2;
			// break;
			// }
			// // 出现对子
			// if (card1Point == card2Point) {
			// personBillNum = personBillNum * 2;
			// if (personBillNum < 5) {
			// personBillNum = 5;
			// }
			// }
			// // 同花色加2
			// if (card1Color == card2Color) {
			// personBillNum = personBillNum + 2;
			// }
			//
			// int cardDif = Math.abs(card1Point - card2Point);
			//
			// if (cardDif < 2) {
			//
			// } else if (cardDif == 2) {
			//
			// } else if (cardDif == 3) {
			// personBillNum = personBillNum - 2;
			// } else if (cardDif == 4) {
			// personBillNum = personBillNum - 4;
			// } else {
			// personBillNum = personBillNum - 5;
			// }
			//
			// if (card1Point < 12 && card2Point < 12 & cardDif < 3) {
			// personBillNum = personBillNum + 1;
			// }
			//
			// PlayerCore.getInstance().setBillNum(personBillNum);
			// }
		} catch (Exception e) {
			// TODO: handle exception
		}
		return action;
	}
}
