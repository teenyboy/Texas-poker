package core;

import java.io.IOException;

import state.ActionState;
import main.Competition;
import main.Game;
import msgtool.MsgUtil;

public class Core {

	public Core() {
		// TODO Auto-generated constructor stub
	}

	public void algorithmCore() throws IOException {

		int action = 0;

		if (Competition.getInstance().getFlopCards().size() == 0
				&& Game.player.getHold() != null) {
			TwoCore twoCore = new TwoCore();
			action = twoCore.getTwoCore();
		}

		if (Competition.getInstance().getFlopCards().size() == 3
				&& Competition.getInstance().getTurnCards().size() == 0
				&& Competition.getInstance().getRiverCards().size() == 0) {
			// FiveCore fiveCore = new FiveCore();
			// fiveCore.getFiveCore();
			action = 1;
		}

		setActionNum(action);
	}

	private void setActionNum(int actionNum) {
		if (actionNum <= 4 && actionNum >= 0) {
			String action = ActionState.setActionState(actionNum);

			if (actionNum == 2) {

				int raiseNum = 50;
				PlayerCore.getInstance().setRaise(raiseNum);

				action = action
						+ String.valueOf(PlayerCore.getInstance().getRaise());
			}
			sendMsg(action);
		}
	}

	private void sendMsg(String actionString) {
		MsgUtil msgUtil = new MsgUtil();

		try {
			byte[] actionMsg = msgUtil.toSocket(actionString);
			Game.outData.write(actionMsg);
			Game.outData.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
