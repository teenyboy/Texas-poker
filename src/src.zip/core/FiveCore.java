package core;

import java.util.ArrayList;

import util.CardJudge;
import main.Card;
import main.Competition;
import main.Game;

public class FiveCore {

	public FiveCore() {
		// TODO Auto-generated constructor stub
	}

	public void getFiveCore() {

		ArrayList<Card> holdCards = Game.personHashMap.get(Game.my_id)
				.getHold();

		ArrayList<Card> flopCards = Competition.getInstance().getFlopCards();
		// 凑出手牌
		ArrayList<Card> cards = new ArrayList<Card>();

		cards.add(holdCards.get(0));
		cards.add(holdCards.get(1));
		cards.add(flopCards.get(0));
		cards.add(flopCards.get(1));
		cards.add(flopCards.get(2));

		CardJudge cardJudge = new CardJudge(cards);
		cardJudge.getCardJudge();

	}
}
