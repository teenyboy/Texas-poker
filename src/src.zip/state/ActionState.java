package state;

import util.WritetoFile;
import main.Game;

public class ActionState {
	public final static int CHECK = 0;
	public final static int CALL = 1;
	public final static int RAISE = 2;
	public final static int ALL_IN = 3;
	public final static int FOLD = 4;

	public static int getActionState(String actionMsg) {
		if (actionMsg.equals("check")) {
			return CHECK;
		} else if (actionMsg.equals("call")) {
			return CALL;
		} else if (actionMsg.equals("raise")) {
			return RAISE;
		} else if (actionMsg.equals("all_in")) {
			return ALL_IN;
		} else if (actionMsg.equals("fold")) {
			return FOLD;
		} else {
			WritetoFile.getInstance(Game.my_id).writeMsg("action is wrong");
			return -1;
		}
	}

	public static String setActionState(int action) {

		String actionStateString = "";

		switch (action) {
		case 0:
			actionStateString = "check";
			break;
		case 1:
			actionStateString = "call";
			break;
		case 2:
			actionStateString = "raise ";
			break;
		case 3:
			actionStateString = "all_in";
			break;
		case 4:
			actionStateString = "fold";
			break;
		default:
			actionStateString = "";
			break;
		}
		return actionStateString;
	}
}
